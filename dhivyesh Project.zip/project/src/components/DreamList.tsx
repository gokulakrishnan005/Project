import React from 'react';

const DreamList: React.FC = () => {
  // Mock data for demonstration
  const dreams = [
    {
      id: 1,
      date: '2024-03-15',
      content: 'I was flying over a city made of crystal, the buildings reflecting rainbow light. A snake appeared in the sky, transforming into a golden bridge.',
      interpretation: 'Flying represents freedom and transcendence. The crystal city might symbolize clarity in your life goals. The snake transforming into a bridge suggests personal transformation and overcoming obstacles.',
      symbols: ['Flying', 'Crystal', 'Snake', 'Bridge', 'Transformation'],
      mood: 'fantasy',
    },
    {
      id: 2,
      date: '2024-03-14',
      content: 'I found myself back in school, but all the classrooms were underwater. I could breathe normally, and the water was warm and comforting.',
      interpretation: 'Being in school suggests a current learning experience in your life. The underwater environment represents deep emotional or subconscious exploration. The ability to breathe underwater might indicate comfort with emotional situations.',
      symbols: ['School', 'Water', 'Breathing'],
      mood: 'thrilling',
    },
  ];

  const getMoodColor = (mood: string) => {
    const colors = {
      fantasy: 'bg-purple-500',
      horror: 'bg-red-500',
      thrilling: 'bg-orange-500',
      humor: 'bg-green-500',
      sad: 'bg-blue-500',
    };
    return colors[mood as keyof typeof colors] || 'bg-gray-500';
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-indigo-300 mb-4">Recent Dreams</h2>
      {dreams.map((dream) => (
        <div key={dream.id} className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center space-x-3">
              <h3 className="text-lg font-medium text-indigo-300">Dream #{dream.id}</h3>
              <span className={`px-3 py-1 rounded-full text-sm text-white ${getMoodColor(dream.mood)}`}>
                {dream.mood.charAt(0).toUpperCase() + dream.mood.slice(1)}
              </span>
            </div>
            <span className="text-sm text-gray-400">{dream.date}</span>
          </div>
          <p className="text-gray-300 mb-4">{dream.content}</p>
          <div className="bg-gray-700 rounded-lg p-4 mb-4">
            <h4 className="font-medium text-indigo-300 mb-2">AI Interpretation</h4>
            <p className="text-gray-300">{dream.interpretation}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {dream.symbols.map((symbol, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-gray-700 text-indigo-300 rounded-full text-sm"
              >
                {symbol}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default DreamList;