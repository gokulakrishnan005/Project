import React from 'react';

interface MenuItem {
  icon: React.ReactNode;
  label: string;
  id: string;
}

interface SidebarProps {
  menuItems: MenuItem[];
  currentSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ menuItems, currentSection, onSectionChange }) => {
  return (
    <aside className="w-64 bg-gray-800 shadow-lg">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-indigo-300 mb-8">DreamSense AI</h2>
        <nav>
          <ul className="space-y-4">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                    currentSection === item.id
                      ? 'bg-indigo-600 text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-indigo-300'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </aside>
  );
}

export default Sidebar;