import React, { useState } from 'react';
import { Send } from 'lucide-react';

const moods = [
  { value: 'fantasy', label: 'Fantasy', color: 'bg-purple-500' },
  { value: 'horror', label: 'Horror', color: 'bg-red-500' },
  { value: 'thrilling', label: 'Thrilling', color: 'bg-orange-500' },
  { value: 'humor', label: 'Humor', color: 'bg-green-500' },
  { value: 'sad', label: 'Sad', color: 'bg-blue-500' },
];

// Enhanced dream themes and patterns
const dreamThemes = {
  movement: {
    patterns: ['fly', 'walk', 'run', 'swim', 'jump', 'climb', 'fall', 'chase', 'escape', 'travel'],
    interpretation: 'Movement in dreams often reflects your life journey and how you navigate challenges.',
    detailed: 'The way you move in dreams can symbolize your approach to life situations. Smooth movement suggests confidence, while restricted movement might indicate feeling held back.',
    psychological: 'Movement patterns in dreams often represent the psyche\'s journey toward individuation and personal growth.'
  },
  environment: {
    patterns: ['house', 'building', 'ocean', 'mountain', 'forest', 'city', 'room', 'school', 'work', 'garden'],
    interpretation: 'Your dream environment reflects your current emotional and mental space.',
    detailed: 'The setting of your dream often mirrors your internal landscape. Natural environments might represent your connection to instincts, while man-made structures could symbolize social constructs and personal boundaries.',
    psychological: 'Dream environments represent different aspects of the psyche and the contexts in which personal growth occurs.'
  },
  interactions: {
    patterns: ['talk', 'meet', 'fight', 'help', 'avoid', 'search', 'find', 'lose', 'give', 'receive'],
    interpretation: 'Interactions in dreams reflect your relationships and social dynamics.',
    detailed: 'The way you interact with dream figures can reveal patterns in your relationships and communication styles.',
    psychological: 'Dream interactions often represent internal dialogues between different aspects of the self.'
  },
  emotions: {
    patterns: ['fear', 'joy', 'anger', 'peace', 'anxiety', 'love', 'hate', 'confusion', 'clarity', 'excitement'],
    interpretation: 'Emotional themes in dreams often highlight feelings you\'re processing.',
    detailed: 'The emotions experienced in dreams can point to unresolved feelings or emotional processing in your waking life.',
    psychological: 'Dream emotions often represent the psyche\'s attempt to balance and integrate different emotional states.'
  },
  transformation: {
    patterns: ['change', 'grow', 'transform', 'birth', 'death', 'rebuild', 'destroy', 'create', 'learn', 'evolve'],
    interpretation: 'Transformative elements in dreams suggest personal growth and life changes.',
    detailed: 'Themes of transformation often appear during major life transitions or periods of personal development.',
    psychological: 'Transformation in dreams represents the ongoing process of psychological integration and development.'
  }
};

const getDefaultAnalysis = (mood: string) => {
  const moodAnalysis = {
    fantasy: {
      basic: "Your dream carries a magical and imaginative quality that suggests a deep connection to your creative potential.",
      detailed: "The fantastical elements in your dream point to an expansive imagination and possibly a desire to transcend current limitations. Such dreams often emerge when we're exploring new possibilities or seeking creative solutions to life's challenges.",
      psychological: "From a psychological perspective, fantasy dreams often represent our highest aspirations and the unlimited potential of our inner world. They can be invitations to embrace our creative power and imagine new possibilities for our life journey."
    },
    horror: {
      basic: "Your dream reveals important shadows or concerns that your psyche is processing.",
      detailed: "The disturbing elements in your dream might represent anxieties or challenges you're currently facing. Rather than being merely frightening, such dreams often serve as important messages from your unconscious about areas of life that need attention or resolution.",
      psychological: "Horror elements in dreams often represent our confrontation with the unknown parts of ourselves or situations we find challenging. This is a natural part of psychological growth and integration."
    },
    thrilling: {
      basic: "Your dream suggests an exciting period of personal discovery and adventure.",
      detailed: "The dynamic nature of your dream indicates that you're in a period of exciting personal development. Even without common dream symbols, the thrilling atmosphere suggests you're engaging with life's possibilities in an energetic way.",
      psychological: "Thrilling dreams often reflect our readiness to embrace change and take on new challenges. They can indicate a healthy engagement with life's adventures and opportunities for growth."
    },
    humor: {
      basic: "Your dream reflects a playful and light-hearted approach to processing life experiences.",
      detailed: "The humorous elements in your dream suggest you're finding ways to approach life's situations with flexibility and creativity. This can be a healthy sign of emotional resilience and adaptability.",
      psychological: "Humor in dreams often represents psychological flexibility and the ability to transform challenging experiences into opportunities for growth and learning."
    },
    sad: {
      basic: "Your dream is helping you process and integrate deeper emotional experiences.",
      detailed: "The melancholic quality of your dream suggests you're working through important emotional material. This is a valuable process that can lead to greater self-understanding and emotional depth.",
      psychological: "Sad dreams often facilitate important emotional processing and can lead to greater psychological integration and healing. They're often precursors to significant personal insights."
    }
  };

  return moodAnalysis[mood as keyof typeof moodAnalysis];
};

const DreamInput: React.FC = () => {
  const [dream, setDream] = useState('');
  const [selectedMood, setSelectedMood] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<{
    themes: string[];
    interpretation: string;
    detailedAnalysis: string;
    psychologicalPerspective: string;
    mood: string;
  } | null>(null);

  const analyzeDreamContent = (text: string): string[] => {
    const lowercaseText = text.toLowerCase();
    const words = lowercaseText.split(/\s+/);
    
    return Object.entries(dreamThemes).reduce((themes: string[], [theme, data]) => {
      const hasThemePatterns = data.patterns.some(pattern => 
        words.some(word => word.includes(pattern))
      );
      if (hasThemePatterns) {
        themes.push(theme);
      }
      return themes;
    }, []);
  };

  const generateInterpretation = (identifiedThemes: string[], dreamText: string, mood: string) => {
    if (identifiedThemes.length === 0) {
      const defaultAnalysis = getDefaultAnalysis(mood);
      return {
        basic: defaultAnalysis.basic,
        detailed: defaultAnalysis.detailed,
        psychological: defaultAnalysis.psychological
      };
    }

    const themeInterpretations = identifiedThemes.map(theme => 
      dreamThemes[theme as keyof typeof dreamThemes].interpretation
    );

    const detailedAnalyses = identifiedThemes.map(theme =>
      dreamThemes[theme as keyof typeof dreamThemes].detailed
    );

    const psychologicalInsights = identifiedThemes.map(theme =>
      dreamThemes[theme as keyof typeof dreamThemes].psychological
    );

    // Mood context analysis
    const moodContext = `The ${mood} emotional tone of this dream suggests ${
      mood === 'fantasy' ? 'a period of creative exploration and possibility in your life.'
      : mood === 'horror' ? 'you may be processing fears or confronting challenging aspects of your experience.'
      : mood === 'thrilling' ? 'you\'re engaging with dynamic changes or exciting developments in your life.'
      : mood === 'humor' ? 'you\'re finding ways to process life experiences through a lighter perspective.'
      : 'you\'re working through deep emotional material that needs attention and integration.'
    }`;

    return {
      basic: themeInterpretations.join(' ') + ' ' + moodContext,
      detailed: detailedAnalyses.join('\n\n'),
      psychological: psychologicalInsights.join('\n\n')
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));

      const identifiedThemes = analyzeDreamContent(dream);
      const { basic, detailed, psychological } = generateInterpretation(identifiedThemes, dream, selectedMood);

      setAnalysis({
        themes: identifiedThemes,
        interpretation: basic,
        detailedAnalysis: detailed,
        psychologicalPerspective: psychological,
        mood: selectedMood
      });

      setDream('');
      setSelectedMood('');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl shadow-md p-6 mb-8 border border-gray-700">
      <h2 className="text-2xl font-semibold text-indigo-300 mb-4">Record Your Dream</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <textarea
            className="w-full h-32 p-4 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none text-gray-100 placeholder-gray-400"
            placeholder="Describe your dream in detail, including what happened, how you felt, and any significant elements you remember..."
            value={dream}
            onChange={(e) => setDream(e.target.value)}
          ></textarea>
        </div>
        <div className="mb-6">
          <label className="block text-indigo-300 mb-2">Dream Mood</label>
          <div className="flex flex-wrap gap-2">
            {moods.map((mood) => (
              <button
                key={mood.value}
                type="button"
                onClick={() => setSelectedMood(mood.value)}
                className={`px-4 py-2 rounded-full text-white transition-all ${
                  selectedMood === mood.value
                    ? `${mood.color} ring-2 ring-white`
                    : 'bg-gray-600 hover:bg-gray-500'
                }`}
              >
                {mood.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center space-x-2 bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!dream || !selectedMood || isAnalyzing}
          >
            <span>{isAnalyzing ? 'Analyzing Dream...' : 'Analyze Dream'}</span>
            <Send size={18} />
          </button>
        </div>
      </form>

      {analysis && (
        <div className="mt-6 p-4 bg-gray-700 rounded-lg border border-gray-600">
          <h3 className="text-xl font-semibold text-indigo-300 mb-3">Dream Analysis</h3>
          
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-medium text-indigo-300 mb-2">Core Themes</h4>
              <div className="flex flex-wrap gap-2 mb-4">
                {analysis.themes.map((theme, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-gray-600 text-indigo-200 rounded-full text-sm capitalize"
                  >
                    {theme}
                  </span>
                ))}
              </div>
              <p className="text-gray-200">{analysis.interpretation}</p>
            </div>

            <div>
              <h4 className="text-lg font-medium text-indigo-300 mb-2">Detailed Analysis</h4>
              <p className="text-gray-200 whitespace-pre-line">{analysis.detailedAnalysis}</p>
            </div>

            <div>
              <h4 className="text-lg font-medium text-indigo-300 mb-2">Psychological Perspective</h4>
              <p className="text-gray-200 whitespace-pre-line">{analysis.psychologicalPerspective}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DreamInput;