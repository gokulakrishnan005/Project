import React, { useState } from 'react';
import { Brain, BookOpen, Users, BarChart3, BookMarked } from 'lucide-react';
import DreamInput from './components/DreamInput';
import DreamList from './components/DreamList';
import Sidebar from './components/Sidebar';

function App() {
  const [currentSection, setCurrentSection] = useState('journal');

  const menuItems = [
    { icon: <Brain size={24} />, label: 'Dream Journal', id: 'journal' },
    { icon: <BookOpen size={24} />, label: 'Interpretations', id: 'interpretations' },
    { icon: <Users size={24} />, label: 'Community', id: 'community' },
    { icon: <BarChart3 size={24} />, label: 'Insights', id: 'insights' },
    { icon: <BookMarked size={24} />, label: 'Resources', id: 'resources' },
  ];

  const renderContent = () => {
    switch (currentSection) {
      case 'journal':
        return (
          <>
            <DreamInput />
            <DreamList />
          </>
        );
      case 'interpretations':
        return (
          <div className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700">
            <h2 className="text-2xl font-bold text-indigo-300 mb-4">Dream Interpretations</h2>
            <p className="text-gray-300">Explore common dream symbols and their meanings.</p>
          </div>
        );
      case 'community':
        return (
          <div className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700">
            <h2 className="text-2xl font-bold text-indigo-300 mb-4">Dream Community</h2>
            <p className="text-gray-300">Connect with other dreamers and share experiences.</p>
          </div>
        );
      case 'insights':
        return (
          <div className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700">
            <h2 className="text-2xl font-bold text-indigo-300 mb-4">Dream Insights</h2>
            <p className="text-gray-300">Analyze patterns and trends in your dream journal.</p>
          </div>
        );
      case 'resources':
        return (
          <div className="bg-gray-800 rounded-xl shadow-md p-6 border border-gray-700">
            <h2 className="text-2xl font-bold text-indigo-300 mb-4">Dream Resources</h2>
            <p className="text-gray-300">Access guides and materials about dream interpretation.</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-gray-900 to-indigo-950">
      <Sidebar menuItems={menuItems} currentSection={currentSection} onSectionChange={setCurrentSection} />
      <main className="flex-1 p-8">
        <div className="max-w-4xl mx-auto">
          <header className="mb-8">
            <h1 className="text-4xl font-bold text-indigo-300 mb-2">DreamSense AI</h1>
            <p className="text-lg text-indigo-400">Unlock the mysteries of your subconscious mind</p>
          </header>
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;